export { AnalyticsView } from '../../super-admin/views/AnalyticsView';
